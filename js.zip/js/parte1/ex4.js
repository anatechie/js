//Operador ternário: 
// Receba um número via prompt e mostre no console: 

//Exercício 4:

//Fora do bloco
let numero = 10;
console.log(numero);
//Dentro do bloco


if (true){
    
    //Variavel sobrescrita:
    let numero = 20;
    console.log(numero);
}
console.log(numero);