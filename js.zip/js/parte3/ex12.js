let frutas = ["mamao", "kiwi", "maca"];

for(let fruta of frutas){
    console.log(fruta);
    }