//Operador Ternário:
// Receba um número via prompt e mostre no console:
//"Positivo" se maior que 0, "Negativo" se menor que 0, ou "Zero" caso contrário, usando apenas operador ternário.

//Exercício 8:

//declarando variavel e recebendo dado(entrada de dados):
let num = prompt("Informe um número: ");
console.log(num);

//Processamento de dados
let verifica = num > 0 ? "Positivo" : (num < 0 ? "Negativo" : "Zero");

//Saida
console.log(verifica);